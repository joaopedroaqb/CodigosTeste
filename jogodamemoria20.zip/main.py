import pygame
import random

pygame.init()

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

WIDTH = 800
HEIGHT = 600
CARD_WIDTH = 100
CARD_HEIGHT = 100
FPS = 30

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Jogo da Memória")

clock = pygame.time.Clock()

board = []
for row in range(4):
    for col in range(4):
        board.append((col * CARD_WIDTH, row * CARD_HEIGHT))


numbers = list(range(1, 9)) * 2
random.shuffle(numbers)

selected_cards = []
selected_positions = []

found_cards = []

def draw_board():
    screen.fill(WHITE)
    for i, pos in enumerate(board):
        card = pygame.Rect(pos[0], pos[1], CARD_WIDTH, CARD_HEIGHT)
        if i in selected_positions or i in found_cards:
            pygame.draw.rect(screen, BLACK, card)
            number_text = pygame.font.SysFont(None, 48).render(str(numbers[i]), True, RED)
            text_width = number_text.get_width()
            text_height = number_text.get_height()
            screen.blit(number_text, (pos[0] + CARD_WIDTH // 2 - text_width // 2, pos[1] + CARD_HEIGHT // 2 - text_height // 2))
        else:
            pygame.draw.rect(screen, RED, card)
    for col in range(1, 4):
        pygame.draw.line(screen, BLACK, (col * CARD_WIDTH, 0), (col * CARD_WIDTH, HEIGHT), 3)
    for row in range(1, 4):
        pygame.draw.line(screen, BLACK, (0, row * CARD_HEIGHT), (WIDTH, row * CARD_HEIGHT), 3)
    pygame.display.flip()

game_over = False
while not game_over:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if len(selected_cards) < 2:
                mouse_pos = pygame.mouse.get_pos()
                for i, pos in enumerate(board):
                    card_rect = pygame.Rect(pos[0], pos[1], CARD_WIDTH, CARD_HEIGHT)
                    if card_rect.collidepoint(mouse_pos) and i not in selected_positions and i not in found_cards:
                        selected_cards.append(numbers[i])
                        selected_positions.append(i)
                        if len(selected_cards) == 2:
                            if selected_cards[0] == selected_cards[1]:
                                found_cards.extend(selected_positions)
                            selected_cards.clear()
                            selected_positions.clear()
    draw_board()
    clock.tick(FPS)

pygame.quit()
